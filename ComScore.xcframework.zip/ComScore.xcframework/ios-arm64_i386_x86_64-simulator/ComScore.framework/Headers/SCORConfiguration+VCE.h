//
// Copyright (c) 2017 comScore. All rights reserved.
//

#import "SCORConfiguration.h"


@interface SCORConfiguration()

/**
 *  If either VCE is enabled or not for the current configuration.
 */
@property(readonly) BOOL vceEnabled __deprecated;

@end
