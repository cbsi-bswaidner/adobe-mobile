//
// Copyright (c) 2017 comScore. All rights reserved.
//

#import "SCORClientConfigurationBuilder.h"

@interface SCORClientConfigurationBuilder()

/**
 *  Enables or disables VCE.
 */
@property(nonatomic) BOOL vceEnabled __deprecated;

@end
